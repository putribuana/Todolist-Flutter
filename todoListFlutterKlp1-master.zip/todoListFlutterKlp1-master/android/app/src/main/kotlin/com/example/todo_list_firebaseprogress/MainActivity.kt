package com.example.todo_list_firebaseprogress

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
